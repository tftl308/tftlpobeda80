<?php
use \Bitrix\Landing\Manager;
use \Bitrix\Landing\Assets;
use \Bitrix\Main\Loader;

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
{
	die();
}

if (!Loader::includeModule('landing'))
{
	return;
}

Manager::setTheme();
$assets = Assets\Manager::getInstance();
$assets->addAsset('landing_auto_font_scale');

$APPLICATION->ShowProperty('FooterJS');
?>
<footer>
    <div class="footer container">
        <div class="footer-block">
            <a href="/"><img src="<?=SITE_TEMPLATE_PATH?>/assets/img/h-logo.png" alt="logo" class="footer__logo"></a>
            <span class="footer__title">УДО ИИ ТУСУР, 2019</span>
        </div>
        <div class="footer-block">
            <p class="footer__address">
                ул. 19 Гвардейской Дивизии, 9А <br>
                пр. Ленина, 40, офис 127
            </p>
            <a href="mailto:do@fdo.tusur.ru" class="footer__email">do@fdo.tusur.ru</a>
        </div>
        <div class="footer-block">
            <a href="https://regulations.tusur.ru/documents/917" class="footer__link" target="_blank">Лицензия на образовательную деятельность</a>
            <a href="https://regulations.tusur.ru/documents/6" class="footer__link" target="_blank">Свидетельство об аккредитации</a>
            <a href="https://regulations.tusur.ru/documents/161" class="footer__link" target="_blank">Политика конфиденциальности</a>
        </div>
        <div class="footer-block">
            <a href="tel:+7 3822 70-17-36" class="footer__phone">+7 3822 70-17-36</a>
            <a href="#" class="footer__call"  data-popup-id="popup_call">заказать звонок</a>
        </div>
    </div>
</footer>
<div class="reviews-popup" id="popup_call">
    <div class="reviews-popup__overlay"></div>
    <div class="reviews-popup__container popup-call__container">
        <h3>Обратная связь</h3>
        <form class='popup-call__form'>
            <input type="text" class="popup-call__text" name="name" placeholder="Имя" required>
            <input type="tel" class="popup-call__phone" name="phone" placeholder="Телефон" required>
            <input type="text" class="popup-call__city" name="city" placeholder="Город" required>
            <input type="submit" class="popup-call__submit" value="Отправить">
            <div style="position:relative;">
            <input type="checkbox" class="search-form__checkbox" name="agree-call" id="agree-call" required style="position: absolute; opacity: 0; ">
            <label for="agree-call" class="search-form__checkbox-label course-popup-content-form__label" style="position: relative; margin-top: 15px;">
                Я согласен на обработку персональных данных. <a href="https://regulations.tusur.ru/documents/161" target="_blank">Политика конфиденциальности</a>
            </label>
            </div>
        </form>
        <div class="reviews-popup__close"></div>
    </div>
</div>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/assets/js/bundle.js?v=1.47"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?=SITE_TEMPLATE_PATH?>/assets/js/accept-cookie.js"></script>
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(64761271, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/64761271" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<style>
    .tablebodytext{
        display: none;}
    .d-block{
        display: block !important;
    }
</style>
</main>
<?$APPLICATION->ShowProperty('BeforeBodyClose');?>
</body>
</html>