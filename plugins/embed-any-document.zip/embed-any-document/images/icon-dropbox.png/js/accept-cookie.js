$(function () {
    var accepted = window.localStorage.getItem("accept-cookie");
    if (navigator.cookieEnabled && !accepted) {
        $('body').append(
            '<style>' +
                '#accept-cookie {' +
                    'position: fixed;' +
                    'left: 0;' +
                    'bottom: 0;' +
                    'width: 100%;' +
                    'z-index: 1000;' +
                    'background: rgba(0, 31, 60, 0.9);' +
                    'font-size: 12px;' +
                    'line-height: 1.5;' +
                    'color: white;' +
                    'text-align: justify;' +
                '}' +
                '#accept-cookie .container {' +
                    'display: flex;' +
                    'position: relative;' +
                    'margin: 0 auto;' +
                    'padding: 20px;' +
                    'justify-content: center;' +
                    'align-items: center;' +
                '}' +
                '#accept-cookie button {' +
                    'margin-left: 30px;' +
                    'padding: 10px 50px;' +
                    'background: none;' +
                    'border: white 1px solid;' +
                    'border-radius: 10px;' +
                    'color: white;' +
                    'cursor: pointer;' +
                    'transition: 0.1s;' +
                '}' +
                '#accept-cookie button:hover {' +
                    'background: rgb(0, 31, 60);' +
                '}' +
                '@media(max-width: 767px) {' +
                    '#accept-cookie .container {' +
                        'flex-wrap: wrap;' +
                    '}' +
                '}' +
                '@media(min-width: 768px) {' +
                    '#accept-cookie .container {' +
                        'width: 750px;' +
                    '}' +
                '}' +
                '@media(min-width: 992px) {' +
                    '#accept-cookie .container {' +
                        'width: 970px;' +
                    '}' +
                '}' +
                '@media(min-width: 1200px) {' +
                    '#accept-cookie .container {' +
                        'width: 1170px;' +
                    '}' +
                '}' +
            '</style>' +
            '<div id="accept-cookie">' +
            '<div class="container">' +
            '<p>' +
            'Для того, чтобы мы могли качественно предоставить Вам услуги, мы используем cookies, которые сохраняются на Вашем компьютере (сведения о местоположении; ip-адрес; тип, язык, версия ОС и браузера; тип устройства и разрешение его экрана; источник, откуда пришел на сайт пользователь; какие страницы открывает и на какие кнопки нажимает пользователь; эта же информация используется для обработки статистических данных использования сайта посредством интернет-сервисов Google Analytics и Яндекс.Метрика). Нажимая кнопку «СОГЛАСЕН», Вы подтверждаете то, что Вы проинформированы об использовании cookies на нашем сайте. Отключить cookies Вы можете в настройках своего браузера' +
                    '</p>' +
                    '<button>Согласен</button>' +
                '</div>' +
            '</div>'
        );

        $('#accept-cookie button').on('click', function () {
            window.localStorage.setItem("accept-cookie", true);
            $('#accept-cookie').fadeOut(200);
        })
    }
})